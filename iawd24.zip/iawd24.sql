-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 20, 2024 at 03:18 PM
-- Server version: 8.0.30
-- PHP Version: 8.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iawd24`
--

-- --------------------------------------------------------

--
-- Table structure for table `about_section`
--

CREATE TABLE `about_section` (
  `id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `about_section`
--

INSERT INTO `about_section` (`id`, `title`, `name`, `description`, `photo`) VALUES
(6, 'Web Developer', 'LOVELU', 'What is Lorem Ipsum?\r\n\r\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has ', '66c4a4d763777.ddddd.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `subject` text COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`, `status`) VALUES
(2, 'Remedios Kidd', 'wyguwy@mailinator.com', 'Quibusdam magnam sae', 'Tempora ea laboriosa', 1),
(4, 'Dai Parrish', 'kydozy@mailinator.com', 'Totam laborum Earum', 'Occaecat quibusdam e', 1),
(5, 'Lana Dean', 'fybywudity@mailinator.com', 'Voluptas est nobis ', 'Debitis do ut earum ', 1),
(6, 'Baker Jensen', 'nadivy@mailinator.com', 'Reprehenderit aut a', 'Ullam tempora proide', 1),
(7, 'Melyssa Pollard', 'tekyvah@mailinator.com', 'Officia obcaecati ip', 'Adipisci neque fuga', 0),
(8, 'Audra Wilson', 'nifu@mailinator.com', 'Facere sunt beatae i', 'Sunt numquam asperna', 0),
(10, 'mehedi', 'mehedi@gmail.com', 'CSE', 'ami osfdogh', 0);

-- --------------------------------------------------------

--
-- Table structure for table `logo_images`
--

CREATE TABLE `logo_images` (
  `id` int NOT NULL,
  `header_logo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `footer_logo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logo_images`
--

INSERT INTO `logo_images` (`id`, `header_logo`, `footer_logo`) VALUES
(1, '66c4a3a8f0f93.png', '66c4a3a90f55b.png');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `portfolio`
--

INSERT INTO `portfolio` (`id`, `title`, `category`, `image`, `status`) VALUES
(1, 'Web Development', 'Laravel', '66c159cc07486.jpg', 1),
(2, 'Web Development', 'Wordpress', '66c159e6cb54a.jpg', 1),
(3, 'Graphics', ' Branding Design', '66c159ff2e987.jpg', 1),
(4, 'FullStrack ', 'Developer', '66c17cfe28ed3.jpg', 1),
(5, 'Application ', 'Development', '66c15a6c58b41.jpg', 0),
(6, 'Wordpress', 'This is wordpress', '66c4b1bf740a7.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `services_section`
--

CREATE TABLE `services_section` (
  `id` int NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services_section`
--

INSERT INTO `services_section` (`id`, `title`, `description`, `status`) VALUES
(1, 'Graphics Branding Design ', 'It can change the way we feel about a company and the products & services they offer.', 1),
(2, 'FullStrack  Development ', 'It can change the way we feel about a company and the products & services they offer.', 1),
(3, 'Front End Design Development', 'It can change the way we feel about a company and the products & services they offer.', 1),
(4, 'Digital Content Marketing', 'It can change the way we feel about a company and the products & services they offer.', 0),
(5, 'Application devlopment', 'It can change the way we feel about a company and the products & services they offer.', 1),
(6, 'Videography Photography', 'It can change the way we feel about a company and the products & services they offer.', 0),
(7, 'Wordpress Development', 'It can change the way we feel about a company and the products & services they offer.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` int NOT NULL,
  `skill_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `percentage` int NOT NULL,
  `status` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skill_name`, `percentage`, `status`) VALUES
(1, 'Html', 95, 1),
(2, 'CSS', 80, 1),
(3, 'Bootstrap', 75, 1),
(4, 'JavaScript', 60, 0),
(5, 'Jquery', 50, 1),
(6, 'PHP', 85, 1),
(14, 'laravel', 50, 1),
(15, 'XML', 35, 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`id`, `name`, `description`, `image`, `message`) VALUES
(1, 'Rose Hogan', 'Sapiente molestiae n', '66c364bd6104a.jpg', 'Ex sit culpa et no'),
(4, 'Noel Patton', 'Rerum amet tempor q', NULL, 'Numquam explicabo T'),
(5, 'Bertha Jackson', 'Esse reprehenderit', '66c364e23a7ef.jpg', 'Veniam qui aute atq'),
(6, 'Sophia Sims', 'Accusantium iure mol', '66c3651262dcd.jpg', 'Non corrupti aperia'),
(11, 'Barrett Sawyer', 'Debitis est ut magni', '66c4b01da2d1b.jpg', 'Nisi qui illo aspern');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int NOT NULL,
  `Name` text COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `Country` text COLLATE utf8mb4_general_ci NOT NULL,
  `Gender` text COLLATE utf8mb4_general_ci NOT NULL,
  `Photo` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Role` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `Name`, `Email`, `Password`, `Country`, `Gender`, `Photo`, `Role`) VALUES
(1, 'Lovelu', 'lovelu500564@gmail.com', '$2y$10$kyy223e7zOYFjH4B4upeh.54AL2Aj4nT2Nh/BIkW/7rn4MgLm/AWm', 'BAN', 'male', '66c4a2d11737e.jpg', 1),
(2, 'Sohag and Robiul', 'kilap@mailinator.com', '$2y$10$ny9Aeb5j4lDAuUItEezb0O61qeJPyrwajbf8gSCPTtBSPUVh5nqii', 'IND', 'male', '66bb56c6c0ae0.jpg', 2),
(3, 'Santa', 'feledo@mailinator.com', '$2y$10$tYgARg8P9lY7Q9tk1AManOu8c3KZlWF9yxvaRRt2DxBHH1PxvKu5K', 'BAN', 'female', '66c409c75de36.jpg', 3),
(9, 'Ronan Casey', 'lyhawyty@mailinator.com', '$2y$10$4orhnaHvOoJ7viRQtpVWIuYIvlaLUSTRZFbx9mYaKvYTkypHGNCcO', 'USE', 'female', NULL, NULL),
(11, 'Xaviera Nash', 'cepomu@mailinator.com', '$2y$10$YbWKL2CWp4sK9QknnuR55.QXttLvdz5Yw98TteXaydB92I894NoaS', 'PIK', 'male', NULL, NULL),
(12, 'Harper Gallagher', 'tysaz@mailinator.com', '$2y$10$gFLcs0abwFVZ6XzWqwPyM.FZq2gzc1/P0KDrHKGSnCTgA/CdF2iq6', 'ARG', 'male', '66c4095858cf8.jpg', NULL),
(13, 'Indira Sears', 'foqo@mailinator.com', '$2y$10$I7P2t8G5xL2XkRtnjJotPugoe3mZ1S9a9uR7oos/fxXB99510SnbK', 'IND', 'male', NULL, NULL),
(16, 'Ella Clark', 'tuvuxe@mailinator.com', '$2y$10$AmVNSLg46ye0RmRstNQOQekxqeV/SDjE4cjHMjttTKbJtOrvTmT3y', 'ARG', 'female', NULL, NULL),
(17, 'mehedi', 'mehedi@gmail.com', '$2y$10$r.tZMnQqHRgUnHWQgqjs1./x1Os4G0C031ztUWrsik7R6.1J0Omw.', 'BAN', 'male', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_section`
--
ALTER TABLE `about_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logo_images`
--
ALTER TABLE `logo_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services_section`
--
ALTER TABLE `services_section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about_section`
--
ALTER TABLE `about_section`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `logo_images`
--
ALTER TABLE `logo_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `services_section`
--
ALTER TABLE `services_section`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
